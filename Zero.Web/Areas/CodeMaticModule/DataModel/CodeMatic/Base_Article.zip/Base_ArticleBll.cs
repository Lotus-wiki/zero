using Zero.Entity;
using Zero.Repository;
using Zero.Utility;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Zero.Business
{
    /// <summary>
    /// ���±�
    /// </summary>
    public class Base_ArticleBll : RepositoryFactory<Base_Article>
    {
    }
}