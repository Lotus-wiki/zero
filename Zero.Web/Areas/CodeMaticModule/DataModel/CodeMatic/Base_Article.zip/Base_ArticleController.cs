using Zero.Business;
using Zero.Entity;
using Zero.Utility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Zero.Web.Areas.CommonModule.Controllers
{
    /// <summary>
    /// ���±�������
    /// </summary>
    public class Base_ArticleController : PublicController<Base_Article>
    {
    }
}