//=====================================================================================
// All Rights Reserved , Copyright @ ABC 2015
// Software Developers @ ABC 2015
//=====================================================================================

using Zero.Entity;
using Zero.Repository;
using Zero.Utilitiy;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Zero.Business
{
    /// <summary>
    /// �ӿڲ���
    /// <author>
    ///		<name>abc</name>
    ///		<date>2015.09.09 14:22</date>
    /// </author>
    /// </summary>
    public class Base_InterfaceManageParameterBll : RepositoryFactory<Base_InterfaceManageParameter>
    {
    }
}