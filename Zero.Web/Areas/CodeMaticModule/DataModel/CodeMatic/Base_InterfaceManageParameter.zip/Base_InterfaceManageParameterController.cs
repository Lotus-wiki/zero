using Zero.Business;
using Zero.Entity;
using Zero.Utilitiy;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LeaRun.WebApp.Areas.CommonModule.Controllers
{
    /// <summary>
    /// �ӿڲ���������
    /// </summary>
    public class Base_InterfaceManageParameterController : PublicController<Base_InterfaceManageParameter>
    {
    }
}