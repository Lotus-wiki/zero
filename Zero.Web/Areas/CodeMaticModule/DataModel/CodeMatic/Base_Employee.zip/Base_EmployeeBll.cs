//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ְԱ��Ϣ��
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.08.27 13:43</date>
    /// </author>
    /// </summary>
    public class Base_EmployeeBll : RepositoryFactory<Base_Employee>
    {
    }
}